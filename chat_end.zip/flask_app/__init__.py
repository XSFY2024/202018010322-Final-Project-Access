# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: __init__.py
@time: 2021/11/10 15:49
"""
from flask import Flask
from flask_cors import CORS
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)


CORS(app, supports_credentials=True)

user = "root"
password = "123456"
database = "chat"
app.config["SQLALCHEMY_DATABASE_URI"] = "mysql://%s:%s@localhost:3306/%s" % (user, password, database)


SQLALCHEMY_TRACK_MODIFICATIONS = True


app.config['SQLALCHEMY_ECHO'] = True


app.config['SQLALCHEMY_COMMIT_ON_TEARDOWN'] = False


db = SQLAlchemy(app)

from flask_app.user import user_blueprint
from flask_app.task import task_blueprint

app.register_blueprint(user_blueprint, url_prefix="/user")
app.register_blueprint(task_blueprint, url_prefix="/task")
