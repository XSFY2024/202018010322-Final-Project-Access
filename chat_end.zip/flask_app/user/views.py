# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: views
@time: 2021/11/10 16:01
"""
from flask import request

from flask_app.common.utils import BaseResponse
from flask_app.user import user_blueprint
from .models import db, UserModel
from ..task.models import ChatModel

api = user_blueprint

REQUIRED_INFO = " is a must!"

def row2dict(row):

    out_dict = {}
    for column in row.__table__.columns:
        out_dict[column.name] = str(getattr(row, column.name))
    return out_dict


@api.route("/register", methods=["POST"])
def register():
    """

    :return:
    """

    _id = request.json.get("id", None)
    account_id = request.json.get("account_id", None)
    password = request.json.get("password", None)

    if account_id is None:
        return BaseResponse().fail(msg="account_id" + REQUIRED_INFO)
    if password is None:
        return BaseResponse().fail(msg="password" + REQUIRED_INFO)

    user = UserModel.query.filter_by(id=_id).first()
    if user is not None:
        return BaseResponse().fail(msg="error")

    user = UserModel.query.filter_by(account_id=account_id).first()
    if user is not None:
        return BaseResponse().fail(msg="error！")

    user = UserModel(id=_id, account_id=account_id, password=password)
    db.session.add(user)
    db.session.commit()
    return BaseResponse().success(data=row2dict(user))

@api.route("/login", methods=["POST"])
def login():
    """

    :return:
    """

    account_id = request.json.get("account_id", None)
    password = request.json.get("password", None)

    if account_id is None:
        return BaseResponse().fail(msg="account_id" + REQUIRED_INFO)
    if password is None:
        return BaseResponse().fail(msg="password" + REQUIRED_INFO)

    user = UserModel.query.filter_by(account_id=account_id).first()
    if user is None:
        return BaseResponse().fail(msg="user not exist！")

    if user.password != password:
        return BaseResponse().fail(msg="password error！")
    return BaseResponse().success(data=row2dict(user))


@api.route("/change_username", methods=["POST"])
def change_username():


    account_id = request.headers.get("Authorization", None)
    new_account_id = request.json.get("new_username", None)

    if account_id is None:
        return BaseResponse().fail(msg="account_id" + REQUIRED_INFO)
    if new_account_id is None:
        return BaseResponse().fail(msg="new_username" + REQUIRED_INFO)

    user = UserModel.query.filter_by(account_id=new_account_id).first()
    if user is not None:
        return BaseResponse().fail(msg="The user name is unavailable!")

    # 查找聊天记录中的account_id，将其替换为new_account_id
    chat = ChatModel.query.filter(ChatModel.sender_id == account_id).all()
    for i in chat:
        i.sender_id = new_account_id
    chat = ChatModel.query.filter(ChatModel.reciever_id == account_id).all()
    for i in chat:
        i.reciever_id = new_account_id
    db.session.commit()

    user = UserModel.query.filter_by(account_id=account_id).first()
    user.account_id = new_account_id
    db.session.commit()
    return BaseResponse().success(data=row2dict(user))



@api.route("/get_random_user", methods=["GET"])
def get_random_user():
    """

    :return
    """
    account_id = request.headers.get("Authorization", None)
    user = UserModel.query.filter(UserModel.account_id != account_id).order_by(db.func.random()).first()
    return BaseResponse().success(data=[row2dict(user)])

@api.route("/get_user/<account_id>", methods=["GET"])
def get_user(account_id):
    """

    :return
    """

    self_account_id = request.headers.get("Authorization", None)
    user = UserModel.query.filter_by(account_id=account_id).first()
    if user is None:
        return BaseResponse().fail(msg="user not exist！")
    if user.account_id == self_account_id:
        return BaseResponse().fail(msg="user not exist！")
    return BaseResponse().success(data=[row2dict(user)])








