# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: models
@time: 2021/11/10 16:01
"""
from datetime import datetime

from flask_app import db

"""


"""

class UserModel(db.Model):
    # 定义表名
    __tablename__ = "user"
    # 定义字段
    id = db.Column(db.Integer, primary_key=True)
    account_id = db.Column(db.String(255), nullable=False, unique=True)
    password = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)





