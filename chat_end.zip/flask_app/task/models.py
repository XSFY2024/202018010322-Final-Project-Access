# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: models
@time: 2021/11/10 16:01
"""
from datetime import datetime

from flask_app import db



class ChatModel(db.Model):

    __tablename__ = "chat"

    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.String(255), nullable=False)
    reciever_id = db.Column(db.String(255), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.now)
    content = db.Column(db.String(255),nullable=False)





