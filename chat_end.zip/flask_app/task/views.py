# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: views
@time: 2021/11/10 16:01
"""
import time

from flask import request

from flask_app.common.utils import BaseResponse
from flask_app.task import task_blueprint
from .models import db, ChatModel


api = task_blueprint

REQUIRED_INFO = " is a must!"

def row2dict(row):
    """
    参考文档 https://stackoverflow.com/questions/1958219/convert-sqlalchemy-row-object-to-python-dict
    将model转换为dict
    :param row: Sqlalchemy model
    :return: 输出的字典
    """
    out_dict = {}
    for column in row.__table__.columns:
        out_dict[column.name] = str(getattr(row, column.name))
    return out_dict


@api.route("/send", methods=["POST"])
def send():
    """

    :return:
    """

    sender_id = request.headers.get("Authorization", None)
    reciever_id = request.json.get("reciever_id", None)
    content = request.json.get("content", None)
    if reciever_id is None:
        return BaseResponse().fail(msg="reciever_id" + REQUIRED_INFO)
    if content is None:
        return BaseResponse().fail(msg="content" + REQUIRED_INFO)

    chat = ChatModel(sender_id=sender_id, reciever_id=reciever_id, content=content)
    db.session.add(chat)
    db.session.commit()

    chat = ChatModel.query.filter(ChatModel.sender_id == sender_id, ChatModel.reciever_id == reciever_id).all()
    chat += ChatModel.query.filter(ChatModel.sender_id == reciever_id, ChatModel.reciever_id == sender_id).all()
    chat = sorted(chat, key=lambda x: x.created_at)
    return BaseResponse().success(data=[row2dict(i) for i in chat])


@api.route("/get/<reciever_id>", methods=["GET"])
def get(reciever_id):
    """

    :return:
    """
    sender_id = request.headers.get("Authorization", None)

    if reciever_id is None:
        return BaseResponse().fail(msg="reciever_id" + REQUIRED_INFO)

    chat = ChatModel.query.filter(ChatModel.sender_id == sender_id, ChatModel.reciever_id == reciever_id).all()
    chat += ChatModel.query.filter(ChatModel.sender_id == reciever_id, ChatModel.reciever_id == sender_id).all()
    chat = sorted(chat, key=lambda x: x.created_at)
    return BaseResponse().success(data=[row2dict(i) for i in chat])

@api.route("/get_chat_list", methods=["GET"])
def get_chat_list():
    """

    :return:
    """
    sender_id = request.headers.get("Authorization",None)
    chat = ChatModel.query.filter(ChatModel.sender_id == sender_id).all()
    chat += ChatModel.query.filter(ChatModel.reciever_id == sender_id).all()
    chat = sorted(chat, key=lambda x: x.created_at)
    chat_list = []
    for i in chat:
        if i.sender_id == sender_id:
            chat_list.append(i.reciever_id)
        else:
            chat_list.append(i.sender_id)
    chat_list = list(set(chat_list))
    res = []
    for i in chat_list:
        res.append({"account_id":i})



    return BaseResponse().success(data=res)




