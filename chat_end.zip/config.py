# encoding: utf-8
"""
@version: 1.0
@author: Jarrett
@file: config.py
@time: 2021/11/10 15:49
"""
